# 🚀 PROYECTO COMPLETO - Bitcoin Predicción 10 Días

## ✅ NOTEBOOKS FINALES GENERADOS

### 📊 **1. 01_EDA_Bitcoin_FINAL_10DIAS.ipynb**
**Análisis Exploratorio de Datos**

**Contenido:**
- ✅ Carga de datos históricos de Bitcoin
- ✅ Análisis descriptivo y visualizaciones
- ✅ **Creación de 10 variables target** (Tendencia_dia1 a Tendencia_dia10)
- ✅ Análisis de distribución por día
- ✅ Gráficos de tendencias por día
- ✅ Split Train/Test (80/20 temporal)
- ✅ Exportación a `/RAW`

**Output:**
- `Train_Bitcoin.csv` (17 columnas: 7 originales + 10 targets)
- `Test_Bitcoin.csv` (17 columnas: 7 originales + 10 targets)

---

### 🔧 **2. 02_Preprocessing_Bitcoin_FINAL_10DIAS.ipynb**
**Preprocesamiento Completo**

**Contenido:**
- ✅ Carga de Train/Test desde `/RAW`
- ✅ **Feature Engineering** (6 features explicadas en detalle)
  - daily_return, MA_7, MA_30, volatility_14, RSI_14, volume_ratio
- ✅ Eliminación de columnas redundantes
- ✅ Manejo de NaNs
- ✅ **Winsorization** (1%-99% percentil, explicada paso a paso)
- ✅ **RobustScaler** (comparado vs StandardScaler)
- ✅ Verificación de integridad
- ✅ Exportación a `/PROCESSED`

**Output:**
- `Train_Bitcoin_Processed.csv` (19 columnas: 9 features + 10 targets)
- `Test_Bitcoin_Processed.csv` (19 columnas: 9 features + 10 targets)

---

### 🤖 **3. 03_ModelSelection_Bitcoin_FINAL_10DIAS.ipynb**
**Modelado y Evaluación**

**Contenido:**
- ✅ Carga de datos procesados desde `/PROCESSED`
- ✅ Separación de X (9 features) e y (10 targets)
- ✅ **Modelo Baseline** (Dummy Classifier)
- ✅ **Random Forest Multi-Output** (10 modelos internos)
- ✅ **XGBoost Multi-Output** (10 modelos internos)
- ✅ **LightGBM Multi-Output** (10 modelos internos)
- ✅ **Evaluación día por día** (Accuracy, Precision, Recall, F1, MCC)
- ✅ **Visualizaciones:**
  - Comparación de modelos
  - Predicciones día por día (muestras individuales)
  - Feature Importance
  - Matrices de confusión por día
  - Distribución de errores
- ✅ **Exportación de modelos** (.pkl)
- ✅ **Exportación de resultados** (.csv, .json, .png)
- ✅ [OPCIONAL] Optimización con Optuna

**Output (en `/MODELS`):**
- `best_model_[nombre].pkl` - Mejor modelo entrenado
- `model_baseline.pkl`, `model_random_forest.pkl`, `model_xgboost.pkl`, `model_lightgbm.pkl`
- `metrics_[modelo].csv` - Métricas por día de cada modelo
- `model_comparison.csv` - Comparación entre modelos
- `predictions_test.csv` - Predicciones finales
- `model_config.json` - Configuración del proyecto
- `feature_importance.png` - Gráfico de importancia
- `confusion_matrices.png` - Matrices por día
- `model_comparison.png` - Comparación visual
- `error_distribution.png` - Análisis de errores

---

## 📋 FLUJO COMPLETO DEL PROYECTO

```
┌──────────────────────────────────────────────────────────────────┐
│ 01_EDA_Bitcoin_FINAL_10DIAS.ipynb                               │
├──────────────────────────────────────────────────────────────────┤
│ INPUT:  ./RAW/DATOS_BITCOIN.csv                                 │
│ ACCIÓN:                                                          │
│   - Análisis exploratorio                                       │
│   - Crear 10 variables target (día por día)                     │
│   - Split temporal Train/Test (80/20)                           │
│ OUTPUT:                                                          │
│   - ./RAW/Train_Bitcoin.csv (17 cols)                           │
│   - ./RAW/Test_Bitcoin.csv (17 cols)                            │
└──────────────────────────────────────────────────────────────────┘
                              ↓
┌──────────────────────────────────────────────────────────────────┐
│ 02_Preprocessing_Bitcoin_FINAL_10DIAS.ipynb                     │
├──────────────────────────────────────────────────────────────────┤
│ INPUT:                                                           │
│   - ./RAW/Train_Bitcoin.csv                                     │
│   - ./RAW/Test_Bitcoin.csv                                      │
│ ACCIÓN:                                                          │
│   - Feature Engineering (6 features)                            │
│   - Eliminar columnas redundantes                               │
│   - Winsorization (1%-99%)                                      │
│   - RobustScaler (fit solo en train)                            │
│ OUTPUT:                                                          │
│   - ./PROCESSED/Train_Bitcoin_Processed.csv (19 cols)           │
│   - ./PROCESSED/Test_Bitcoin_Processed.csv (19 cols)            │
└──────────────────────────────────────────────────────────────────┘
                              ↓
┌──────────────────────────────────────────────────────────────────┐
│ 03_ModelSelection_Bitcoin_FINAL_10DIAS.ipynb                    │
├──────────────────────────────────────────────────────────────────┤
│ INPUT:                                                           │
│   - ./PROCESSED/Train_Bitcoin_Processed.csv                     │
│   - ./PROCESSED/Test_Bitcoin_Processed.csv                      │
│ ACCIÓN:                                                          │
│   - Entrenar 4 modelos Multi-Output                             │
│   - Evaluar día por día (10 días)                               │
│   - Visualizar predicciones                                     │
│   - Seleccionar mejor modelo                                    │
│   - Exportar todo                                               │
│ OUTPUT:                                                          │
│   - ./MODELS/*.pkl (modelos entrenados)                         │
│   - ./MODELS/*.csv (métricas y resultados)                      │
│   - ./MODELS/*.png (visualizaciones)                            │
│   - ./MODELS/*.json (configuración)                             │
└──────────────────────────────────────────────────────────────────┘
```

---

## 🎯 ESTRUCTURA DE DATOS POR FASE

### Fase 1: Después del EDA
```
Train/Test en ./RAW/ (17 columnas):
├── Originales (7):
│   ├── timeOpen, open, high, low, close
│   ├── volume, marketCap
│
└── Targets (10):
    ├── Tendencia_dia1  → ¿Día 1 será alcista?
    ├── Tendencia_dia2  → ¿Día 2 será alcista?
    ├── ...
    └── Tendencia_dia10 → ¿Día 10 será alcista?
```

### Fase 2: Después del Preprocessing
```
Train/Test en ./PROCESSED/ (19 columnas):
├── Features (9 - escaladas con RobustScaler):
│   ├── Originales (3): close, volume, marketCap
│   └── Engineered (6): daily_return, MA_7, MA_30,
│                        volatility_14, RSI_14, volume_ratio
│
└── Targets (10 - SIN escalar):
    ├── Tendencia_dia1 hasta Tendencia_dia10
    └── Valores: 0 (bajista) o 1 (alcista)
```

### Fase 3: Después del ModelSelection
```
Modelos en ./MODELS/:
├── Modelos entrenados (.pkl)
├── Métricas por día y globales (.csv)
├── Visualizaciones (.png)
└── Configuración (.json)
```

---

## 🔑 CARACTERÍSTICAS DEL PROYECTO

### ✅ Metodología Correcta:
- **Sin Data Leakage**: 
  - Targets usan `shift(-N)` correctamente
  - RobustScaler fit solo con train
  - Split temporal (no aleatorio)
  - Elimina últimas 10 filas sin futuro

- **Multi-Output Learning**:
  - 10 modelos internos (uno por cada día)
  - Predicción simultánea de los 10 días
  - Evaluación independiente por día

- **Robustez**:
  - Winsorization en lugar de eliminar outliers
  - RobustScaler (robusto a outliers)
  - Class weight balanced (si es necesario)
  - Validación exhaustiva

### ✅ Documentación Completa:
- Cada técnica explicada con ejemplos
- Winsorization vs eliminación (comparado)
- RobustScaler vs StandardScaler (comparado)
- Código comentado y estructurado
- Visualizaciones interpretables

### ✅ Modelos Implementados:
1. **Baseline** (Dummy Classifier) → Benchmark mínimo
2. **Random Forest** → Robusto, interpretable
3. **XGBoost** → Alta precisión, eficiente
4. **LightGBM** → Rápido, escalable

---

## 📊 MÉTRICAS DE EVALUACIÓN

### Por Día (10 tablas):
- Accuracy
- Precision
- Recall
- F1-Score
- MCC (Matthews Correlation Coefficient)

### Globales (promedio):
- Accuracy promedio de los 10 días
- F1-Score promedio
- MCC promedio

### Visualizaciones:
- Comparación de modelos (barras)
- Predicciones día por día (muestras individuales)
- Accuracy por día (línea)
- Feature Importance (barras horizontales)
- Matrices de confusión (10 heatmaps)
- Distribución de errores (histograma)

---

## 🚀 CÓMO EJECUTAR EL PROYECTO

### Paso 1: Ejecutar EDA
```bash
jupyter notebook 01_EDA_Bitcoin_FINAL_10DIAS.ipynb
```
- Ejecuta todas las celdas
- Verifica que se crean `Train_Bitcoin.csv` y `Test_Bitcoin.csv` en `./RAW/`

### Paso 2: Ejecutar Preprocessing
```bash
jupyter notebook 02_Preprocessing_Bitcoin_FINAL_10DIAS.ipynb
```
- Ejecuta todas las celdas
- Verifica que se crean datasets procesados en `./PROCESSED/`

### Paso 3: Ejecutar ModelSelection
```bash
jupyter notebook 03_ModelSelection_Bitcoin_FINAL_10DIAS.ipynb
```
- Ejecuta todas las celdas
- Verifica que se crea la carpeta `./MODELS/` con todos los archivos

### Paso 4: Revisar Resultados
```
./MODELS/
├── best_model_*.pkl           → Mejor modelo para producción
├── model_comparison.csv       → Comparación de todos los modelos
├── metrics_*.csv              → Métricas detalladas por modelo
├── predictions_test.csv       → Predicciones finales
├── model_config.json          → Configuración del proyecto
├── feature_importance.png     → Top features
├── confusion_matrices.png     → Rendimiento por día
├── model_comparison.png       → Comparación visual
└── error_distribution.png     → Análisis de errores
```

---

## 🔧 REQUISITOS

### Librerías Necesarias:
```
pandas>=1.3.0
numpy>=1.21.0
matplotlib>=3.4.0
seaborn>=0.11.0
scikit-learn>=1.0.0
xgboost>=1.5.0
lightgbm>=3.3.0
joblib>=1.1.0
```

### Librerías Opcionales:
```
catboost>=1.0.0    # Para CatBoost (opcional)
optuna>=3.0.0      # Para optimización (opcional)
```

### Instalación:
```bash
pip install pandas numpy matplotlib seaborn scikit-learn xgboost lightgbm joblib

# Opcionales:
pip install catboost optuna
```

---

## 📝 NOTAS IMPORTANTES

### 1. Sobre las 10 Variables Target:
- Cada variable predice un día específico (1 a 10)
- Son **independientes** (no acumulativas)
- Permiten visualización día por día
- Útiles para estrategias de trading flexibles

### 2. Sobre Data Leakage:
- **CRÍTICO**: El proyecto está diseñado para evitar data leakage
- No modificar el orden de los notebooks
- No mezclar train y test antes del escalado
- No eliminar las últimas 10 filas manualmente

### 3. Sobre el Rendimiento:
- El notebook 03 puede tardar **5-15 minutos** en ejecutarse completamente
- La optimización con Optuna (opcional) puede tardar **10-30 minutos**
- Se recomienda ejecutar en una máquina con al menos 8GB RAM

### 4. Sobre Producción:
- El mejor modelo se guarda en `.pkl` y está listo para producción
- Incluye todas las transformaciones (Winsorization, RobustScaler)
- La configuración está documentada en `model_config.json`

---

## 🎯 PRÓXIMOS PASOS (Mejoras Futuras)

1. **Más Features**:
   - Indicadores técnicos avanzados (Ichimoku, Fibonacci, etc.)
   - Datos on-chain (hash rate, direcciones activas, etc.)
   - Datos macroeconómicos (DXY, SPY, tasas de interés)

2. **Ensemble de Modelos**:
   - Voting Classifier (combinar RF, XGB, LGBM)
   - Stacking (meta-modelo)

3. **Backtesting**:
   - Implementar estrategia de trading basada en predicciones
   - Calcular Sharpe Ratio, Sortino Ratio, Max Drawdown
   - Comparar con Buy & Hold

4. **Deep Learning**:
   - LSTM / GRU para secuencias temporales
   - Transformer (atención temporal)

5. **Deploy**:
   - API REST con FastAPI
   - Docker container
   - CI/CD pipeline

---

## 📧 SOPORTE

Para cualquier duda o problema:
1. Revisa que los 3 notebooks se ejecuten en orden
2. Verifica que todas las librerías estén instaladas
3. Comprueba que los datasets se generan correctamente en cada fase

---

## ✅ CHECKLIST FINAL

- [ ] Ejecutado 01_EDA_Bitcoin_FINAL_10DIAS.ipynb
- [ ] Verificado que `./RAW/Train_Bitcoin.csv` existe (17 columnas)
- [ ] Verificado que `./RAW/Test_Bitcoin.csv` existe (17 columnas)
- [ ] Ejecutado 02_Preprocessing_Bitcoin_FINAL_10DIAS.ipynb
- [ ] Verificado que `./PROCESSED/Train_Bitcoin_Processed.csv` existe (19 columnas)
- [ ] Verificado que `./PROCESSED/Test_Bitcoin_Processed.csv` existe (19 columnas)
- [ ] Ejecutado 03_ModelSelection_Bitcoin_FINAL_10DIAS.ipynb
- [ ] Verificado que `./MODELS/` contiene todos los archivos
- [ ] Revisado `./MODELS/model_comparison.csv`
- [ ] Revisado gráficos en `./MODELS/*.png`
- [ ] Modelo listo para producción

---

🎉 **¡PROYECTO COMPLETADO!** 🎉
